package com.example.emil.licencjat;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ExpandableListAdapter;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

import org.w3c.dom.Text;

public class CalendarNoteActivity extends AppCompatActivity {

    public TextView mDateView;
    private EditText mCalendarNote;
    private PickedDate mPD;
    private  String mCalendarNoteName;
    private boolean mSavedNote=false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar_note);


        mDateView = (TextView) findViewById(R.id.dateView);
        mCalendarNote= (EditText) findViewById(R.id.calendarNote);
        mDateView.setText(PickedDate.mShowedDate);

       /* if (PickedDate.getCalendarNote(this, PickedDate.mShowedDate) == null){
            mCalendarNote.setHint("Wprowadź tekst...");
        }
        if(!(PickedDate.getCalendarNote(this, PickedDate.mShowedDate).getmContent().isEmpty())
                && (PickedDate.getCalendarNote(this, PickedDate.mShowedDate).getmContent())!=null ){
            mPD=PickedDate.getCalendarNote(this, PickedDate.mShowedDate);
            mCalendarNote.setText(mPD.getmContent());
            if (mPD.getmContent() != null){
                mCalendarNote.setText(mPD.getmContent());
            }
        }
        */

                mPD=PickedDate.getCalendarNote(this, PickedDate.mShowedDate);
                //if(mPD.getmContent() != null && !mPD.getmContent().trim().isEmpty()){
                try {
                    mCalendarNote.setText(mPD.getmContent());
                } catch (Exception e){
                    e.printStackTrace();
                }

                    //mCalendarNote.setText("tralala");
                //}



        //if (mPD.getmContent() != null){
       //     mCalendarNote.setText(mPD.getmContent());
        //} else{
        //    mCalendarNote= (EditText) findViewById(R.id.calendarNote);
       //}
       // mCalendarNote.setText(mPD.getmContent());
        //mDateView.setText(mPD.getmDate().toString());
       // mPD = PickedDate.getCalendarNote(this, mDateView.getText().toString());
       // mCalendarNote.setText(PickedDate.mShowedContent);

        //mCalendarNoteName = mDateView.getText().toString();

       // mCalendarNote.setText(mPD.getmContent());

        //mCalendarNote
        //if (mCalendarNote != null){

        //}
        //Bundle bundle = getIntent().getExtras();
        //String d = (String) bundle.get("day");
        //String m = (String) bundle.get("month");
        //String y = (String) bundle.get("year");

        //mDateView.setText(d+"-"+m+"-"+y);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_calendarnote_save, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_calendarNote_save:
                saveCalendarNote();
                break;
        }
        return true;
    }

    public void saveCalendarNote(){
        PickedDate pd;
        pd = new PickedDate(mDateView.getText().toString(), mCalendarNote.getText().toString());
        PickedDate.saveCalendarNote(this, pd);
        //isSaved(mDateView.getText().toString(), true);
        Toast.makeText(this, "Zapisano!", Toast.LENGTH_SHORT).show();
        finish();
    }

    public boolean isSaved (String name, boolean _mSavedNote){
        return _mSavedNote;
    }

}
