package com.example.emil.licencjat;

import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

public class AddNoteActivity extends AppCompatActivity {

    private EditText mTitle;
    private EditText mContent;
    private String mNoteName;
    private Note mLoadedNote;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_note);

        mTitle = (EditText) findViewById(R.id.note_title);
        mContent = (EditText) findViewById(R.id.note_content);
        mNoteName = getIntent().getStringExtra("NOTATKA");
        if (mNoteName != null && !mNoteName.isEmpty()){
            mLoadedNote = NoteTools.getNoteByName(this, mNoteName);
            if (mLoadedNote != null){
                mTitle.setText(mLoadedNote.getTitle());
                mContent.setText(mLoadedNote.getContent());
            }
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_note_new, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {
            case R.id.action_note_save:
                saveNote();
                break;
            case R.id.action_note_delete:
                deleteNote();
                break;
        }
        return true;
    }

    private void deleteNote() {
        if (mLoadedNote == null){
            finish();
        } else {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this).setTitle("Usuń")
                    .setMessage("Czy na pewno chcesz usunąć " + mTitle.getText().toString() +"?")
                    .setPositiveButton("Tak", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            NoteTools.deleteNote(getApplicationContext(),
                                    mLoadedNote.getDateTime()+ NoteTools.FILE_EXTENSION);
                            Toast.makeText(getApplicationContext(), "Usunięto notkę", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    })
                    .setNegativeButton("Nie", null)
                    .setCancelable(false);
            dialog.show();

        }
    }

    private void saveNote() {
        Note note;

        if (mTitle.getText().toString().trim().isEmpty()){
            Toast.makeText(this, "Brak tytułu!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (mContent.getText().toString().trim().isEmpty()){
            Toast.makeText(this, "Pusta notatka!", Toast.LENGTH_SHORT).show();
            return;
        }
        if (mLoadedNote == null) {
            note = new Note(System.currentTimeMillis(), mTitle.getText().toString(), mContent.getText().toString());
        } else {
            note = new Note(mLoadedNote.getDateTime(), mTitle.getText().toString(), mContent.getText().toString());
        }
        if (NoteTools.saveNote(this, note)){
            Toast.makeText(this, "Zapisano!", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, "Notka nie została zapisana...", Toast.LENGTH_SHORT).show();
        }
    }
}
