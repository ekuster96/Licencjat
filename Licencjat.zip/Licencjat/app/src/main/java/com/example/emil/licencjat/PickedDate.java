package com.example.emil.licencjat;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

/**
 * Created by Emil on 2018-01-05.
 */

public class PickedDate implements Serializable {
    private String mDate;
    private String mContent=" ";
    public static String mShowedDate;
    public static String mShowedContent;
    public PickedDate(String _mDate, String _mContent){
        mDate=_mDate;
        mContent=_mContent;

    }


    public String getmDate() {
        return mDate;
    }

    public String getmContent() {
        return mContent;
    }

    public void setmDate(String _mDate) {
        mDate = _mDate;
    }

    public void setmContent(String _mContent) {
        mContent = _mContent;
    }



    public static boolean saveCalendarNote (Context context, PickedDate pd) {
        String fileName = pd.getmDate();
        //String fileName = mShowedDate;

        FileOutputStream fos;
        ObjectOutputStream oos;

        try{
            fos = context.openFileOutput(fileName, context.MODE_PRIVATE);
            oos = new ObjectOutputStream(fos);
            oos.writeObject(pd);
            oos.close();
            fos.close();
        } catch (IOException e){
            e.printStackTrace();
            return false;
        }
        return true;
    }

    public static PickedDate getCalendarNote(Context context, String fileName){
        File f = new File(context.getFilesDir(), fileName);

        if (f.exists()){
            FileInputStream fis;
            ObjectInputStream ois;
            PickedDate pDate;
            try{
                fis = context.openFileInput(fileName);
                ois = new ObjectInputStream(fis);

                pDate = (PickedDate) ois.readObject();

                fis.close();
                ois.close();
            }catch (IOException | ClassNotFoundException e){
                e.printStackTrace();
                return null;
            }
            return pDate;
        }

        return null;

    }


}
