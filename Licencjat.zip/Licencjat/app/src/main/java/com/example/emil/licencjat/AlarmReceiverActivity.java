package com.example.emil.licencjat;

import android.content.BroadcastReceiver;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.widget.CompoundButton;
import android.widget.Toast;
import android.widget.ToggleButton;

import static android.support.v4.content.ContextCompat.startActivity;

public class AlarmReceiverActivity extends BroadcastReceiver {
    public static Ringtone ringtone;


    @Override
    public void onReceive(Context context, Intent intent)
    {
        //AlarmActivity.mTButton.findViewById(R.id.toggleButton);
        //AlarmActivity.mTButton.setChecked(true);
        Intent i = new Intent();
        i.setClassName("com.example.emil.licencjat", "com.example.emil.licencjat.AlarmActivity");
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
       // AlarmActivity.mTButton.setChecked(true);
        Toast.makeText(context, "Alarm!", Toast.LENGTH_LONG).show();
        Uri mUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        if (mUri == null)
        {
            mUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
        }
        ringtone = RingtoneManager.getRingtone(context, mUri);

        ringtone.play();
        context.startActivity(i);


    }
}
