package com.example.emil.licencjat;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.util.Calendar;

public class AlarmActivity extends AppCompatActivity {

    TimePicker mPicker;
    PendingIntent mPIntent;
    AlarmManager mAManager;
    ToggleButton mTButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);
        mPicker = (TimePicker) findViewById(R.id.timePicker);
        mPicker.setIs24HourView(true);
        mAManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        mTButton = (ToggleButton) findViewById(R.id.toggleButton);


    }

    public void OnToggleClicked(View view)
    {
        long time;
        if (mTButton.isChecked())
        {
            Toast.makeText(this, "Alarm włączony!", Toast.LENGTH_SHORT).show();
            Calendar calendar = Calendar.getInstance();
            calendar.set(Calendar.HOUR_OF_DAY, mPicker.getCurrentHour());
            calendar.set(Calendar.MINUTE, mPicker.getCurrentMinute());
            Intent intent = new Intent(this, AlarmReceiverActivity.class);
            mPIntent = PendingIntent.getBroadcast(this, 0, intent, 0);

            time=(calendar.getTimeInMillis()-(calendar.getTimeInMillis()%60000));
            if(System.currentTimeMillis()>time)
            {
                time = time + (1000*60*60*24);
            }
            mAManager.setRepeating(AlarmManager.RTC_WAKEUP, time, 100, mPIntent);
            try{
                AlarmReceiverActivity.ringtone.stop();
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
        else
        {
            mAManager.cancel(mPIntent);
            Toast.makeText(this, "Wyłączono alarm!", Toast.LENGTH_SHORT).show();
            try{
                AlarmReceiverActivity.ringtone.stop();
            }
            catch (Exception e){
                e.printStackTrace();
            }
        }
    }


}
