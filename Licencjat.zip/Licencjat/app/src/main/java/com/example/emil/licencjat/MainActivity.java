package com.example.emil.licencjat;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void goToGroups (View view) {
        //Intent intent = new Intent(this, GroupsActivity.class);
        //startActivity(intent);
        Toast.makeText(this, "W trakcie realizacji", Toast.LENGTH_LONG).show();
    }

    public void goToNotes (View view) {
        Intent intent = new Intent(this, NotesActivity.class);
        startActivity(intent);
    }

    public void goToCalendar (View view){
        Intent intent = new Intent(this, CalendarActivity.class);
        startActivity(intent);
    }

    public void goToAlarm (View view){
        Intent intent = new Intent(this, AlarmActivity.class);
        startActivity(intent);
    }

}
