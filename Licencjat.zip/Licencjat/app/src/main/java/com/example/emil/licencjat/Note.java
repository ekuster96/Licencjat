package com.example.emil.licencjat;

import android.content.Context;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * Created by Emil on 2017-12-28.
 */

public class Note implements Serializable{
    private long dateTime;
    private String title;
    private  String content;

    public Note(long _dateTime, String _title, String _content) {
        this.dateTime = _dateTime;
        this.title = _title;
        this.content = _content;
    }

    public long getDateTime() {
        return dateTime;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }

    public void setDateTime(long _dateTime) {
        dateTime = _dateTime;
    }

    public void setTitle(String _title) {
        title = _title;
    }

    public void setContent(String _content) {
        content = _content;
    }

    public String getDateTimeFormatted(Context context)
    {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss",
            context.getResources().getConfiguration().locale);
        sdf.setTimeZone(TimeZone.getDefault());
        return sdf.format(new Date(dateTime));
    }
}
