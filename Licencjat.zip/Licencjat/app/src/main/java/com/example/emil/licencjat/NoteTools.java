package com.example.emil.licencjat;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 * Created by Emil on 2017-12-28.
 */

public class NoteTools {
    public static final String FILE_EXTENSION = ".bin";
    public static boolean saveNote (Context context, Note note) {
        String fileName = String.valueOf(note.getDateTime()) + FILE_EXTENSION;

        FileOutputStream fos;
        ObjectOutputStream oos;

        try{
            fos = context.openFileOutput(fileName, context.MODE_PRIVATE);
            oos = new ObjectOutputStream(fos);
            oos.writeObject(note);
            oos.close();
            fos.close();
        } catch (IOException e){
            e.printStackTrace();
            return false;
        }

        return true;
    }

    public static ArrayList<Note> loadNotes (Context context) {
        ArrayList<Note> notesAL = new ArrayList<>();
        File filesDir = context.getFilesDir();
        ArrayList<String> noteFilesAL = new ArrayList<>();

        for (String file : filesDir.list()){
            if (file.endsWith(FILE_EXTENSION)) {
                noteFilesAL.add(file);
            }
        }
        FileInputStream fis;
        ObjectInputStream ois;

        for (int i=0; i < noteFilesAL.size(); i++){
            try{
                fis = context.openFileInput(noteFilesAL.get(i));
                ois = new ObjectInputStream(fis);
                notesAL.add((Note)ois.readObject());

                fis.close();
                ois.close();
            }catch(IOException | ClassNotFoundException e){
                e.printStackTrace();
                return null;
            }
        }
        return notesAL;
    }

    public static Note getNoteByName(Context context, String fileName){
        File f = new File(context.getFilesDir(), fileName);

        if (f.exists()){
            FileInputStream fis;
            ObjectInputStream ois;
            Note note;
            try{
                fis = context.openFileInput(fileName);
                ois = new ObjectInputStream(fis);

                note = (Note) ois.readObject();

                fis.close();
                ois.close();
            }catch (IOException | ClassNotFoundException e){
                e.printStackTrace();
                return null;
            }
            return note;
        }

        return null;

    }

    public static void deleteNote(Context context, String fileName) {
        File fileDir = context.getFilesDir();
        File f = new File(fileDir, fileName);

        if (f.exists()){
            f.delete();
        }

    }
}
