package com.example.emil.licencjat;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.Calendar;

public class CalendarActivity extends AppCompatActivity {
    TextView mCurrentDate;
    private CalendarView mCalendar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);
       // mCurrentDate = (TextView) findViewById(R.id.currentDate);
        mCalendar = (CalendarView) findViewById(R.id.calendar);
        mCalendar.setFirstDayOfWeek(2);

        mCalendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int day) {
                //Toast.makeText(getApplicationContext(), day + "-" + (month+1) + "-" + year, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), CalendarNoteActivity.class);
                month=month+1;
                String _day = String.valueOf(day);
                String _month= String.valueOf(month);
                String _year= String.valueOf(year);
               // PickedDate pd = new PickedDate(_day + "-" + _month + "-" + _year, null);

               // PickedDate.mShowedDate = String.valueOf(mCurrentDate);

                //mCurrentDate = (TextView) findViewById(R.id.currentDate);
                //mCurrentDate.setText(String.valueOf(day) + "-" + String.valueOf(month+1) + "-" +String.valueOf(year));
                PickedDate.mShowedDate = _day + "-" + _month + "-" + _year; // working
                //mCurrentDate.setText(String.valueOf(day));
                //PickedDate.mDate = String.valueOf(mCurrentDate);
                startActivity(intent);
            }
        });


    }


}
